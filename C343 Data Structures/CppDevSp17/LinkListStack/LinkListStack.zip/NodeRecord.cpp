
class NodeRecord{
public:
	NodeRecord* head;
	int value;
	NodeRecord* next;
};

