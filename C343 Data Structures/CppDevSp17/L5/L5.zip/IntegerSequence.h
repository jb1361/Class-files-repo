#pragma once
#include "Wrapper.h"
#include "Sequence\Sequence0.hpp"

typedef Sequence0<Integer> IntegerSequence;