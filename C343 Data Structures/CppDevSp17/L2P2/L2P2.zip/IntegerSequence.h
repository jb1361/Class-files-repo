#pragma once
#include "Wrapper.h"
#include "BoundedSequence\BoundedSequence1.hpp"

typedef BoundedSequence1<Integer, 5> IntegerSequence;
