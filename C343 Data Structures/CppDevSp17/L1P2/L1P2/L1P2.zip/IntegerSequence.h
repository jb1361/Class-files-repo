#pragma once
#include "Wrapper.h"
#include "Sequence\Sequence1.hpp"

typedef Sequence1<Integer> IntegerSequence;